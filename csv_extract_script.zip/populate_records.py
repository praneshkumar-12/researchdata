import mysql.connector
import csv

'''
CREATE TABLE publications
  (
	 uniqueid            VARCHAR(100),
     title               VARCHAR(500) NOT NULL,
     start_academic_month VARCHAR(10),
     start_academic_year VARCHAR(10),
     end_academic_month  VARCHAR(10),
     end_academic_year   VARCHAR(10),
     first_author        VARCHAR(50) NOT NULL,
     second_author       VARCHAR(50),
     third_author        VARCHAR(50),
     other_authors       VARCHAR(500),
     is_student_author   VARCHAR(1),
     student_name        VARCHAR(50),
     student_batch       VARCHAR(10),
     specification       VARCHAR(30),
     publication_type    VARCHAR(30),
     publication_name    VARCHAR(500),
     publisher           VARCHAR(100),
     year_of_publishing  YEAR,
     month_of_publishing VARCHAR(10),
     volume              INT,
     page_number         VARCHAR(100),
     indexing            VARCHAR(100),
     quartile            VARCHAR(2),
     citation            INT,
     doi                 VARCHAR(500),
     front_page_path     VARCHAR(500),
     url                 VARCHAR(500),
     ISSN                VARCHAR(500)
  );
'''
# conn = mysql.connector.connect(
#     host="localhost", user="root", password="Test-Database4me", database="ssn_new"
# )

# curr = conn.cursor()


def generate_scripts(file_name):
    with open(file_name, "r") as research_file:
        f = open(file_name.replace(".csv", ".txt"), "w")
        f.close()
        research_data = csv.reader(research_file)
        header = next(research_data)
        # print(header)
        for row in research_data:
            data_to_fill = []
            for idx, data in enumerate(row):
                if "'" in data:
                    data = data.replace("'", "\\'")
                # print((idx, data, data == "NULL") if "Assurance" in row[1] else "", end='')
                if "NULL" == data and idx == 23:
                    data_to_fill.append(0)
                    continue
                elif "NULL" == data and idx == 19:
                    # print("replaced")
                    data_to_fill.append(0)
                    continue

                if data == "NULL":
                    data_to_fill.append("'NULL'")
                elif data is None:
                    data_to_fill.append("'NULL'")
                else:
                    if data.isnumeric():
                        data_to_fill.append(data)
                    else:
                        data_to_fill.append("'" + data + "'")
        
            sql = """INSERT INTO publications VALUES({}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {})"""
            command = sql.format(*data_to_fill)
            # print(command)
            with open(file_name.replace(".csv", ".txt"), "a") as script_file:
                script_file.write(command + ";\n")
        
generate_scripts("JUL2021JUN2022/research-data-new-refactored-updated.csv")
generate_scripts("JUL2022JUN2023/research-data-new-refactored.csv")